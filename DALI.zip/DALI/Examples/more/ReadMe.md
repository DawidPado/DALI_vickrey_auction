Here more DALI MAS examples from contributors, mostly from DISIM-UnivAQ students projects.
