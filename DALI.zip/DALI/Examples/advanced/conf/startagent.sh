eval "$2 --noinfo -l $3/active_dali_wi.pl --goal \"start0('conf/mas/$1').\""
