In this folder every agent instance is represented by a text file name (with the agent name) containing the identifier of the agent type from which each agent shall be instanciated
